#ifndef TENANT_H
#define TENANT_H

#include <string>

using namespace std; 

struct tenant {
	string type;
	int budget;
	int agree;
	string name;
};

#endif
